# Xiaomi Mi 5S Plus device_features mods for MIUI 9 (Nougat)

This module activate many features that's deliberately disabled by Xiaomi even tho the device itself supports it such as:
1. Enable camera EIS, camera rec at 60fps, many other camera features related mods.
2. Activate the [Full screen gestures] & disable the hardware capacitive keys.
3. All camera sounds will be disabled.
4. Replace system emoji font with latest Android Pie's emoji.
5. Enable ANT+ capability (thanks to: Paoiw from XDA Devs/MIUI Forum).
6. Add busybox non-symlink for better compatibility with ROM's toybox.
7. GPS & iZat configs fix.